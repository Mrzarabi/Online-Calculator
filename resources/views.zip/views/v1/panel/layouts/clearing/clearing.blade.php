@php
    use App\Models\Clearing;
    use App\Models\Form;
    use App\Models\Calculator;
    use App\Models\Element;
    use Carbon\Carbon;
@endphp
@extends('adminlte::page')
@section('content')

    <div class="container">
        <div class="card custom-back-color-card">
            <div class="card-body pb-0">
                <span class="custom-font-weight badge badge-pill mb-1 {{$order->accept == false ? 'badge-danger' : 'badge-success'}} "> {{ $order->accept == false ? 'Pending' : "Accepted" }} </span>
                @php
                    $clearing = Clearing::where('order_id', $order->id)->first();
                    $form = Form::where('order_id', $order->id)->first();
                    $input = Calculator::where('id', $order->input_currency_type)->first();
                    $output = Element::where('id', $order->output_currency_type)->first();
                @endphp
                @if ($clearing)
                    <span class="custom-font-weight badge badge-pill mb-1 {{$clearing->clear == false ? 'badge-danger' : 'badge-success'}} "> {{ $clearing->clear == false ? 'Not Clear' : "Clear" }} </span>
                @endif
                <div class="text-center w-100">

                    <h6 class="mr-2">Order NO: {{$order->order_no}}</h6>
                    <div class="d-flex justify-content-center align-items-center">

                        <h6 class="mr-2">{{$input->name ? $input->name : 'NO TEXT'}}</h6>
                        <h4 class="mr-2">{{$order->input_number ? $order->input_number : 'NO TEXT'}}</h4>
                        <h6 class="mr-2">{{$order->input_currency_unit ? $order->input_currency_unit : 'NO TEXT'}}</h6>
                    </div>
                        <h3 class="text-danger">TO</h3>
                    <div class="d-flex justify-content-center align-items-center">
                        <h6  class="mr-2">{{$output->name ? $output->name : 'NO TEXT'}}</h6>
                        <h4  class="mr-2">{{$order->output_number ? $order->output_number : 'NO TEXT'}}</h4>
                        <h6  class="mr-2">{{$order->output_currency_unit ? $order->output_currency_unit : 'NO TEXT'}}</h6>
                    </div>
                </div>
                <div class="user">
                    <img src=" {{$order->user->avatar ? $order->user->avatar : '/defaultImages/avatar.png'}} " alt="user" />
                    <div class="user-info">
                        <h5 class="custom-user-info"> {{$order->user->name . ' ' . $order->user->family}} </h5>
                        <small class="custom-user-info"> {{$order->user->email}} </small>
                        <br>
                        <small class="custom-user-info"> {{$order->user->phone ? $order->user->phone : 'NO PHONE' }} </small>
                        <br>
                        <small class="custom-user-info">{{$order->user->address ? $order->user->address : 'NO ADDRESS'}}</small>
                        <br>
                        <small class="custom-user-info"> {{ Carbon::parse($order->created_at)->format('d/m/Y') }} </small>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center mb-2">
                @if ($form)
                    <button type="button" class="btn btn-sm btn-primary mr-1" data-toggle="modal" data-target="#form-{{$form->id}}-sm" data-whatever="@mdo">Show Form</button>
                @endif
            </div>
        </div>
    </div>
    {{-- modal --}}
    @if ($form)
        <div class="modal fade" id="form-{{$form->id}}-sm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content custom-card-color">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="custom-user-info custom-font-size">User PayPal E-mail address: </label>
                            <h6 class="ml-3 mr-3 text-justify mb-3"> {{$form->email ? $form->email : 'NO TEXT'}} </h6>
                        </div>
                        <div class="form-group">
                            <label class="custom-user-info custom-font-size">User content E-mail address: </label>
                            <h6 class="ml-3 mr-3 text-justify mb-3"> {{$form->contact_email ? $form->contact_email : 'NO TEXT'}} </h6>
                        </div>
                        <div class="form-group">
                            <label class="custom-user-info custom-font-size">User PayPal wallet: </label>
                            <h6 class="ml-3 mr-3 text-justify mb-3"> {{$form->wallet ? $form->wallet : 'NO TEXT'}} </h6>
                        </div>
                        @isset($form->telegram)
                            <div class="form-group">
                                <label class="custom-user-info custom-font-size">User Telegram account: </label>
                                <h6 class="ml-3 mr-3 text-justify"> {{$form->telegram}} </h6>
                            </div>
                        @endisset
                        @isset($form->whatsApp)
                            <div class="form-group">
                                <label class="custom-user-info custom-font-size">User WhatsApp account: </label>
                                <h6 class="ml-3 mr-3 text-justify"> {{$form->whatsApp ? $form->whatsApp : 'NO TEXT'}} </h6>
                            </div>
                        @endisset
                        @isset($form->skype)
                            <div class="form-group">
                                <label class="custom-user-info custom-font-size">User Skype account: </label>
                                <h6 class="ml-3 mr-3 text-justify"> {{$form->skype ? $form->skype : 'NO TEXT'}} </h6>
                            </div>
                        @endisset
                        @isset($form->extra)
                            <div class="form-group">
                                <label class="custom-user-info custom-font-size">Extra note on your user transaction: </label>
                                <p class="ml-3 mr-3 text-justify"> {{$form->extra ? $form->extra : 'NO TEXT'}} </p>
                            </div>
                        @endisset
                    </div>
                    <hr/>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    @endif
    {{-- end modal --}}
    <div class="rounded custom-card-color">
        <div class="row">
            <div class="col-8 offset-2">
                <div class="d-flex justify-content-center m-4">
                    <a href=" {{route('orders.index')}} " class="btn btn-primary mr-3 justify-center">Return To Page Orders</a>
                </div>
                    @php
                        $clearing = Clearing::where('order_id', $order->id)->first();
                    @endphp
                <form method="POST" action="{{isset($clearing) ? route('clearing.update', ['clearing' => $clearing->id]) : route('clearing.store')}}" class="mb-4" enctype="multipart/form-data">
                    @isset ($clearing)
                        @method('PUT')
                    @endisset
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control form-control-sm custom-form-control" id="title" name="title" value="{{isset($clearing) ? $clearing->title : old('title')}}">
                        @if ($errors->has('title'))
                            <span class="d-block text-danger">{{ $errors->first('title') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="order_id" value="{{$order->id}}">
                    </div>
                    <div class="form-group">
                        <label for="body">Body</label>
                        <textarea class="form-control form-control-sm custom-form-control" id="body" rows="5" name="body">{{isset($clearing) ? $clearing->body : old('body')}}</textarea>
                        @if ($errors->has('body'))
                            <span class="d-block text-danger">{{ $errors->first('body') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="clear">Clear</label>
                        <div class="input-group">
                            <input type="radio" id="true" class="mt-2 mr-1" name="clear" @isset($clearing->clear) @if($clearing->clear == 1) checked @endif value=1 @else value=1 @endisset >
                            <label for="true" class="pr-3">Clear</label><br>
                            <input type="radio" id="false" class="mt-2 mr-1" name="clear" @isset($clearing->clear) @if($clearing->clear == 0) checked @endif value=0 @else value=0 @endisset>
                            <label for="false" class="pr-3">Not Clear</label><br>
                            <div class="input-group-addon"><i class="ti-layout-grid2-alt"></i></div>
                        </div>
                        @if( $errors->has('clear') )
                            <span class="d-block text-danger">{{ $errors->first('clear') }}</span>
                        @endif
                    </div>
                    <div class="d-flex justify-content-end mt-3">
                        <a href=" {{route('orders.index')}} " class="btn btn-secondary btn-sm mr-2">Cancel</a>
                        <button type="submit" class="btn btn-success btn-sm">Submit</button>
                    </div>
                    @csrf
                </form>
            </div>
        </div>
    </div>
@endsection