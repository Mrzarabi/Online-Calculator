@extends('mail.app')

@section('content')
<div id="main-div">
    <h2 class="main-h2">[Order Number: {{$order->order_no}}] ({{Carbon\Carbon::parse($order->created_at)->format('d/m/Y') }})</h2>
    <h3>Hello I'm {{$data->name . " " . $data->family}}</h3>
    <p>My E-mail is <a href="mailto:{{ $email }}" class="custom-a"> {{ $email }} </a></p>
    <p>My Contact E-mail is <a href="mailto:{{ $contact_email }}" class="custom-a"> {{ $contact_email }} </a></p>
    @if ($data->phone)
        <p>My number is <a href="tel:{{ $data->phone }}"> {{ $data->phone }} </a></p>
    @endif
    <h3>
        I want to trade 
        {{$input->name}} 
        {{$order->input_number}}
        {{$order->input_currency_unit}} 
        TO 
        {{$output->name}} 
        {{$order->output_number}} 
        {{$order->output_currency_unit}}
        .
    </h3>
</div>
@endsection