@extends('mail.app')

@section('content')
<div id="main-div">
    <h3><strong>Hello dear {{$data['name']}}, This Message From Samxpay's Site.</strong></h3>
    <h2>Welcome To Our Site.</h2>
</div>
@endsection